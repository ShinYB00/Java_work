package kosa.oop2;

public class Study extends Role {

	@Override
	public void doing() {
		System.out.println("Study Role");
	}

}
