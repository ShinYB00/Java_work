package kosa.oop2;

// 코드의 독립성 보장함
public abstract class Role {
	// 반드시 가지는 메소드
	public abstract void doing();
	
}
