package kosa.oop2;

public class Work extends Role {

	@Override
	public void doing() {
		System.out.println("Work Role");

	}

}
