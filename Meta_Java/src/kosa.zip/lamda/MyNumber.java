package kosa.lamda;

public interface MyNumber {
	int getMax(int num1, int num2);

}
