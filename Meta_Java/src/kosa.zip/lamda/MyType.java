package kosa.lamda;

public interface MyType {
	//람다식은 추상 메서드가 1개일 때 사용(함수가 하나)
	public void hello();
	
}
