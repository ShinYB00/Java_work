package kosa.lamda;

public interface YourType {
	public void talk(String message);
}
