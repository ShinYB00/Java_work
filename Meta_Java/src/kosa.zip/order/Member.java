package kosa.order;

public class Member {

}
