package kosa.order;

public class Order {

}
