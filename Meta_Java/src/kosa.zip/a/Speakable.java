package kosa.a;

public interface Speakable {
	
	public String speak(); 

}
