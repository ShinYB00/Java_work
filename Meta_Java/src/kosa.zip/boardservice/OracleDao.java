package kosa.boardservice;

public class OracleDao extends Insert {

	@Override
	public void insert() {
		System.out.println("OracleDao");

	}

}
