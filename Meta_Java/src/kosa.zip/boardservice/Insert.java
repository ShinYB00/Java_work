package kosa.boardservice;

public abstract class Insert {

	public abstract void insert();
}
