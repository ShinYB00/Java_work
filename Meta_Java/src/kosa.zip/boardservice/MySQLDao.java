package kosa.boardservice;

public class MySQLDao extends Insert {

	@Override
	public void insert() {
		System.out.println("MySQLDao");

	}

}
